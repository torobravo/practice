package com.baccredomatic.wsrestapi.satai;

public class TokenValidationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TokenValidationException(String message) {
		super(message);
	}
	
	public TokenValidationException(String message, Throwable error) {
		super(message, error);
	}
	
	public TokenValidationException(Throwable error) {
		super(error);
	}

}
