package com.baccredomatic.wsrestapi.satai;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Properties;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.ibm.websphere.security.WebTrustAssociationException;
import com.ibm.websphere.security.WebTrustAssociationFailedException;
import com.ibm.wsspi.security.tai.TAIResult;
import com.ibm.wsspi.security.tai.TrustAssociationInterceptor;
import com.ibm.wsspi.security.token.AttributeNameConstants;

public class OAuthTAI implements TrustAssociationInterceptor, OAuthConstants {
	private static final String VERSION = "1.0.1";
	private static final String DEFAULT_REALM = "defaultRealm";

	private String _publicKeyUrl;
	private String _audience;
	private String _issuer;
	private boolean _isProduction;
	private int _leeway;

	@Override
	public int initialize(Properties props) throws WebTrustAssociationFailedException {
		logDebug(String.format("OAuthTAI::initialize %s v%s", getType(), VERSION));

		if (props == null)
			return 1;

		this._publicKeyUrl = props.getProperty(KEY_PUBLIC_KEY_URL, STRING_EMPTY);
		this._audience = props.getProperty(KEY_AUDIENCE, STRING_EMPTY);
		this._issuer = props.getProperty(KEY_ISSUER, STRING_EMPTY);
		this._isProduction = Boolean.parseBoolean(props.getProperty(KEY_IS_PRODUCTION, "true"));
		this._leeway = Integer.parseInt(props.getProperty(KEY_LEEWAY, "0"));

		return 0;
	}

	@Override
	public boolean isTargetInterceptor(HttpServletRequest request) throws WebTrustAssociationException {
		// This TAI should always be invoked for all web services 
		// protected or unprotected
		return true;
	}

	@Override
	public TAIResult negotiateValidateandEstablishTrust(HttpServletRequest request, HttpServletResponse response)
			throws WebTrustAssociationFailedException {
		try {
			
			logDebug("OAuthTAI::negotiateValidateandEstablishTrust v." + VERSION);

			// Check if there is an Access Token in the request header
			String authHeader = request.getHeader(HEADER_AUTHORIZATION);
			if (authHeader == null || !authHeader.startsWith(BEARER_PREFIX)) {
				logDebug(String.format("OAuthTAI:: Missing %s or %s headers", HEADER_AUTHORIZATION, BEARER_PREFIX));
				return TAIResult.create(HttpServletResponse.SC_UNAUTHORIZED);
			}

			String token = authHeader.substring(BEARER_PREFIX.length());

			// Validate the token
			MsalValidationService service = new MsalValidationService(_publicKeyUrl, _issuer, _audience, _leeway);
			DecodedJWT jwt = service.decodeAndVerifyToken(token, _isProduction);

			// Create the Subject
			String principal = jwt.getSubject();
			String uniqueId = "user:" + DEFAULT_REALM + "/" + principal;

			Hashtable<String, Object> credentials = new Hashtable<>();
			credentials.put(AttributeNameConstants.WSCREDENTIAL_UNIQUEID, uniqueId);
			credentials.put(AttributeNameConstants.WSCREDENTIAL_SECURITYNAME, principal);
			credentials.put(AttributeNameConstants.WSCREDENTIAL_REALM, DEFAULT_REALM);
			
			// this is the magic to map Azure roles to IWS roles
			Claim roleClaim = jwt.getClaim(CLAIM_TYPE_ROLE);
			if (!roleClaim.isNull()) {
				logDebug(String.format("OAuthTAI:: Azure groups: %s for %s", Arrays.toString(roleClaim.asArray(String.class)), principal));
				credentials.put(AttributeNameConstants.WSCREDENTIAL_GROUPS,
						new ArrayList<String>(java.util.Arrays.asList(roleClaim.asArray(String.class))));
			}

			// new up a Subject, then put the hashtable in the private credentials
			Subject subject = new Subject();
			subject.getPublicCredentials().add(credentials);

			TAIResult taiResult = TAIResult.create(HttpServletResponse.SC_OK, principal, subject);

			return taiResult;
			
		} catch (TokenValidationException tvex) {
			logDebug("OAuthTAI::negotiateValidateandEstablishTrust " + tvex.getMessage());
			return TAIResult.create(HttpServletResponse.SC_FORBIDDEN);		
			
		} catch (Exception ex) {
			logDebug("OAuthTAI::negotiateValidateandEstablishTrust " + ex.getMessage());
			return TAIResult.create(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public void cleanup() {
		// Nothing to do here
	}

	@Override
	public String getType() {
		return this.getClass().getName();
	}

	@Override
	public String getVersion() {
		return VERSION;
	}

	private static void logDebug(String msg) {
		System.out.println(msg);
		System.out.flush();
	}

}
