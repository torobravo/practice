package com.baccredomatic.wsrestapi.satai;

public class OAuthError extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public OAuthError(String message) {
		super(message);
	}
	
	public OAuthError(String message, Throwable error) {
		super(message, error);
	}
	
	public OAuthError(Throwable error) {
		super(error);
	}

}
