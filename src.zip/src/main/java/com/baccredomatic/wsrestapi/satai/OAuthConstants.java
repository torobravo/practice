package com.baccredomatic.wsrestapi.satai;

public interface OAuthConstants {

	static final String KEY_PUBLIC_KEY_URL = "PublicKeyUrl";
	static final String KEY_AUDIENCE = "Audience";
	static final String KEY_ISSUER = "Issuer";
	static final String KEY_IS_PRODUCTION = "Production";
	static final String KEY_LEEWAY = "Leeway";
	static final String HEADER_AUTHORIZATION = "Authorization";
	static final String BEARER_PREFIX = "Bearer ";
	static final String CLAIM_TYPE_ROLE = "roles";
	static final String STRING_EMPTY = "";
}
