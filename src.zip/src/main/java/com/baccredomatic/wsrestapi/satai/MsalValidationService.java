package com.baccredomatic.wsrestapi.satai;

import java.net.MalformedURLException;
import java.net.URL;
import java.security.interfaces.RSAPublicKey;
import java.time.Instant;
import java.util.concurrent.TimeUnit;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import com.auth0.jwk.NetworkException;
import com.auth0.jwk.RateLimitReachedException;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;

public final class MsalValidationService {
	private static final int DEFAULT_LEEWAY = 0;
	private final String _issuer;
	private final String _audience;
	private final int _leeway;

	// It is important to reuse this object, as it will cache keys
	private static JwkProvider _provider;

	public MsalValidationService(String publicKeyUrl, String issuer, String audience) {
		this(publicKeyUrl, issuer, audience, DEFAULT_LEEWAY);
	}
	
	public MsalValidationService(String publicKeyUrl, String issuer, String audience, int leeway) {
		this._issuer = issuer;
		this._audience = audience;
		this._leeway = leeway;
		buildProvider(publicKeyUrl);
	}
	
	public DecodedJWT decodeAndVerifyToken(String token, boolean verifySignature) {
		return verifySignature ? 
				decodeAndVerifySignature(token) : 
				decodeAndVerify(token);
	}

	private void buildProvider(String publicKeyUrl) {
		try {
			if (_provider == null) {
				_provider = new JwkProviderBuilder(new URL(publicKeyUrl))
						// cache up to 10 JWKs for up to 24 hours
						.cached(10, 24, TimeUnit.HOURS).build();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
			throw new OAuthError(e);
		}
	}


	private DecodedJWT decodeAndVerifySignature(String token)  {
		Jwk jwk = null;
		Algorithm algorithm = null;

		try {

			DecodedJWT jwt = JWT.decode(token);

			jwk = _provider.get(jwt.getKeyId());
			algorithm = Algorithm.RSA256((RSAPublicKey) jwk.getPublicKey(), null);

			JWTVerifier verifier = JWT.require(algorithm)
					.withIssuer(_issuer)
					.withAudience(_audience)
					.acceptLeeway(_leeway)
					.build();

			return verifier.verify(jwt);
			
		} catch(NetworkException | RateLimitReachedException | IllegalArgumentException nex) {
			nex.printStackTrace();
			throw new OAuthError(nex);			
		} catch(JWTVerificationException | JwkException jwtex) {
			throw new TokenValidationException(jwtex);
		} 
	}

	private DecodedJWT decodeAndVerify(String token) {

		DecodedJWT jwt;
		
		try {
			jwt = JWT.decode(token);
		} catch (JWTDecodeException jwtex) {
			throw new TokenValidationException(jwtex);
		}

		if (jwt.getIssuer() == null || !jwt.getIssuer().equals(_issuer))
			throw new TokenValidationException("The Issuer does not match '" + _issuer + "'");

		if (jwt.getAudience() == null || !jwt.getAudience().contains(_audience))
			throw new TokenValidationException("The Audience does not contain '" + _audience + "'");

		if (jwt.getNotBefore() == null || jwt.getNotBeforeAsInstant().isAfter(Instant.now().plusSeconds(_leeway)) )
			throw new TokenValidationException("The Token can't be used before '" + jwt.getNotBeforeAsInstant() + "'");

		if (jwt.getExpiresAt() == null || jwt.getExpiresAtAsInstant().isBefore(Instant.now().minusSeconds(_leeway)))
			throw new TokenValidationException("The Token has expired '" + jwt.getExpiresAtAsInstant() + "'");

		return jwt;
	}

}
