package com.baccredomatic.wsrestapi.satai;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;
import com.microsoft.aad.msal4j.IConfidentialClientApplication;

public final class TokenServiceImpl {
	private static TokenServiceImpl s_instance;	
	// It is important to reuse this object, as it will cache tokens.
    private static IConfidentialClientApplication s_app;
    
    String _authority;
    String _clientId;
    String _secret;
    String _scope;
	
	private TokenServiceImpl() throws IOException {
		// Load properties file and set properties used throughout the sample
        Properties properties = new Properties();
        properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("application.properties"));

        this._authority = properties.getProperty("AUTHORITY");
        this._clientId = properties.getProperty("CLIENT_ID");
        this._secret = properties.getProperty("SECRET");
        this._scope = properties.getProperty("SCOPE");
	}
	
	public static TokenServiceImpl getInstance() throws IOException {
		if (s_instance == null) {
			s_instance = new TokenServiceImpl();
		}
		return s_instance;
	}
	
	public String getValidAccessToken() throws InterruptedException, ExecutionException, MalformedURLException {
		GetOrCreateApp(_clientId, _secret, _authority);
		
        ClientCredentialParameters clientCredentialParam = ClientCredentialParameters.builder(
                Collections.singleton(_scope))
        .build();

		// The first time this is called, the app will make an HTTP request to the token issuer, so this is slow. Latency can be >1s
		IAuthenticationResult result = s_app.acquireToken(clientCredentialParam).get();
		
		// On subsequent calls, the app will return a token from its cache. It is important to reuse the app object
		
		return result.accessToken();
	}
	
	
	public String getExpiredAccesstoken() {
		return "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IjNQYUs0RWZ5Qk5RdTNDdGpZc2EzWW1oUTVFMCIsImtpZCI6IjNQYUs0RWZ5Qk5RdTNDdGpZc2EzWW1oUTVFMCJ9.eyJhdWQiOiJhcGk6Ly9uaS5jb20ud3NyZXN0YXBpIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvYjEyNjk3MWItNzhlMi00NmU0LWE1MjgtNGE3NjFhMTZhMGJjLyIsImlhdCI6MTczMTc5MzEyOCwibmJmIjoxNzMxNzkzMTI4LCJleHAiOjE3MzE3OTc0NjQsImFjciI6IjEiLCJhaW8iOiJBVFFBeS84WUFBQUE1VFZSQ2pRSThjYVdwVDFaaTY3ZUxWV3N5V1VRSjFFR2FROTlHRnhsT256a2YweG5ueU00cE9taVl5ckhKdW96IiwiYW1yIjpbInB3ZCJdLCJhcHBpZCI6IjczNTUwMzk5LTMwZWYtNGU1Ni1hMmQ4LTgwM2FjZjM0OWIwZSIsImFwcGlkYWNyIjoiMCIsImlwYWRkciI6IjUyLjE3OS4xNjkuMjQwIiwibmFtZSI6IlRvcm8gQnJhdm8iLCJvaWQiOiIyZDAzMmNjMi1hZDlmLTRmNzktOWJjYy1iZTQ3OGU3NTUxYTYiLCJyaCI6IjEuQVU0QUc1Y21zZUo0NUVhbEtFcDJHaGFndktJODhYblp0TjVNaW9JOVdhZXo1NGlEQUkxT0FBLiIsInJvbGVzIjpbIkNyZWF0b3IiXSwic2NwIjoicHJvbW9jaW9uZXMiLCJzdWIiOiJjazNYVVZ3U09zYVhjbm1ScUxIQU5RZE8ybFhwOEMxOU5RM2l3YkpqV0pZIiwidGlkIjoiYjEyNjk3MWItNzhlMi00NmU0LWE1MjgtNGE3NjFhMTZhMGJjIiwidW5pcXVlX25hbWUiOiJ0b3JvYnJhdm9Aamlyb25ocmhvdG1haWwub25taWNyb3NvZnQuY29tIiwidXBuIjoidG9yb2JyYXZvQGppcm9uaHJob3RtYWlsLm9ubWljcm9zb2Z0LmNvbSIsInV0aSI6IjZPNFhaNjVYYmttblk5UUxvSEU2QUEiLCJ2ZXIiOiIxLjAifQ.RU4SlC-QuL3Y3fjHo7Lk9z3-yoQSxkSqEp7hV-yx-578mxFFFLSsW6mUOER5x61tvU0-o-E2vD9LkRL5A2IaBPGYIFlbTXurLeQh8TKJsyQRHDLru36iapiNlbr0mdWUiwUmkWqiPgnm8rUXXPg5tNBqeQrlQS3gXr2C4yAPH6hJBFaOzdGFaQr2Z2wReDcbJRty-ju4vd_IzGkbdV80gHYkROEnIoapzeUr9tXUWNDEqED7JfNj4stfK5oBIRbE5EbpjjKrIpullmZE9vKy1E7l9CbLE3ohC3wky-UOGJ2Mlp2_vQVcKARG_o1de6KlFSeLc8ety9wvggaRh7Y2YQ";
	}
	
    private static void GetOrCreateApp(String clientId, String secret, String authority) throws MalformedURLException {

        if (s_app == null) {
            s_app = ConfidentialClientApplication.builder(
                            clientId,
                            ClientCredentialFactory.createFromSecret(secret))
                    .authority(authority)
                    .build();
        }
    }


}
