package com.baccredomatic.wsrestapi.satai;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.BeforeClass;
import org.junit.Test;

import com.ibm.websphere.security.WebTrustAssociationFailedException;

public class OAuthTAITest implements OAuthConstants{

	private static String s_jwkUrl;
	private static String s_aud;
	private static String s_iss;
	
	@BeforeClass
	public static void setup() throws IOException {
		// Load properties file and set properties used throughout the sample
        Properties properties = new Properties();
        properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("application.properties"));

        s_jwkUrl = properties.getProperty("PUBLIC_KEY_PROVIDER");
        s_aud = properties.getProperty("AUDIENCE");
        s_iss = properties.getProperty("ISSUER");
	}
	
	@Test
	public void testNoAuthoriztionHeader() throws IOException, WebTrustAssociationFailedException {        

		// Mock properties
		Properties props = new Properties();
		props.setProperty(KEY_PUBLIC_KEY_URL, s_jwkUrl);
		props.setProperty(KEY_ISSUER, s_iss);
		props.setProperty(KEY_AUDIENCE, s_aud);
		
		// Mocket servlet request response
		HttpServletRequest mockRequest = mock(HttpServletRequest.class);
		HttpServletResponse mockResponse = mock(HttpServletResponse.class);

		TokenServiceImpl tokenService = TokenServiceImpl.getInstance();
		
		// Test
		OAuthTAI tai = new OAuthTAI();		
		tai.initialize(props);
		tai.negotiateValidateandEstablishTrust(mockRequest, mockResponse);
		
		verify(mockResponse).setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		
	}
}
