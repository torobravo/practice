package com.baccredomatic.wsrestapi.satai;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

/**
 * Unit test for simple App.
 */
public class MsalValidationServiceTest {

	private static String s_jwkUrl;
	private static String s_aud;
	private static String s_iss;
	
	@BeforeClass
	public static void setup() throws IOException {
		// Load properties file and set properties used throughout the sample
        Properties properties = new Properties();
        properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("application.properties"));

        s_jwkUrl = properties.getProperty("PUBLIC_KEY_PROVIDER");
        s_aud = properties.getProperty("AUDIENCE");
        s_iss = properties.getProperty("ISSUER");
	}

	/**
	 * Rigourous Test :-)
	 * @throws IOException 
	 * @throws ExecutionException 
	 * @throws InterruptedException 
	 * @throws MalformedURLException 
	 */
	
	@Test
	@Ignore
	public void verifyToken() throws IOException, InterruptedException, ExecutionException {
		TokenServiceImpl tokenService = TokenServiceImpl.getInstance();
                
		MsalValidationService s_service = new MsalValidationService(s_jwkUrl, s_iss, s_aud);
		
		DecodedJWT jwt = s_service.decodeAndVerifyToken(tokenService.getValidAccessToken(), false);
		
		Assert.assertNotNull(jwt);
	}
	
	@Test
	@Ignore
	public void verifySignatureToken() throws IOException, InterruptedException, ExecutionException {
		TokenServiceImpl tokenService = TokenServiceImpl.getInstance();
		
		MsalValidationService s_service = new MsalValidationService(s_jwkUrl, s_iss, s_aud);
		
		DecodedJWT jwt = s_service.decodeAndVerifyToken(tokenService.getValidAccessToken(), true);
		
		System.out.println("type: " + jwt.getType());
		System.out.println("expires at: " + jwt.getExpiresAt());
		System.out.println("expires at instant" + jwt.getExpiresAtAsInstant() );
		System.out.println("issued at: " + jwt.getIssuedAt());
		System.out.println("issued at instant: " + jwt.getIssuedAtAsInstant());
		System.out.println("not before: " + jwt.getNotBefore());
		System.out.println("not before instante: " + jwt.getNotBeforeAsInstant());
		
		for(Entry<String, Claim> el : jwt.getClaims().entrySet()) {
			System.out.println(el.getKey() + "=" + el.getValue());
		}
		
		Assert.assertNotNull(jwt);
	}

	@Test
	public void verifyExpiredToken() throws IOException {
		TokenServiceImpl tokenService = TokenServiceImpl.getInstance();
		MsalValidationService s_service = new MsalValidationService(s_jwkUrl, s_iss, s_aud);

		TokenValidationException ex = Assert.assertThrows(TokenValidationException.class,
				() -> s_service.decodeAndVerifyToken(tokenService.getExpiredAccesstoken(), false));

		MatcherAssert.assertThat(ex.getMessage(), CoreMatchers.containsString("The Token has expired"));
	}
	
	@Test
	public void verifySignatureExpiredToken() throws IOException {
		TokenServiceImpl tokenService = TokenServiceImpl.getInstance();
		MsalValidationService s_service = new MsalValidationService(s_jwkUrl, s_iss, s_aud);

		TokenValidationException ex = Assert.assertThrows(TokenValidationException.class,
				() -> s_service.decodeAndVerifyToken(tokenService.getExpiredAccesstoken(), true));

		MatcherAssert.assertThat(ex.getMessage(), CoreMatchers.containsString("The Token has expired"));
	}

	
}
